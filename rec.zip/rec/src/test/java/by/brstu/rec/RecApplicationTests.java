package by.brstu.rec;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecApplicationTests {

	@Test
	void contextLoads() {
	}

}
